package com.example.quotexaipro;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int OVERLAY_REQUEST = 2201;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 50, 36, 36);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);
        layout.setBackgroundColor(0xFF101827);

        TextView title = new TextView(this);
        title.setText("QUOTEX AI PRO");
        title.setTextSize(26);
        title.setTextColor(0xFFFFFFFF);
        title.setPadding(0, 0, 0, 18);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("Option C: floating icon + screen-analysis permission scaffold + market-data/AI integration point.\n\nনোট: নিচের সিগন্যাল demo মাত্র; এটি পরীক্ষিত AI prediction নয়।");
        info.setTextSize(16);
        info.setTextColor(0xFFE2E8F0);
        info.setPadding(0, 0, 0, 24);
        layout.addView(info);

        Button enable = new Button(this);
        enable.setText("Enable floating icon");
        enable.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, OVERLAY_REQUEST);
            } else startBubble();
        });
        layout.addView(enable);

        Button capture = new Button(this);
        capture.setText("Screen capture permission (setup)");
        capture.setOnClickListener(v -> {
            // Android requires a system consent dialog before MediaProjection can capture.
            android.media.projection.MediaProjectionManager mgr =
                (android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(mgr.createScreenCaptureIntent(), 2202);
        });
        layout.addView(capture);

        setContentView(layout);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) startBubble();
        } else if (requestCode == 2202 && resultCode == RESULT_OK && data != null) {
            // Consent is received, but a production capture pipeline still needs a foreground
            // MediaProjection service, frame processing and explicit user-visible notification.
            android.widget.Toast.makeText(this,
                "Permission granted for this session. Capture pipeline is not wired in this starter.",
                android.widget.Toast.LENGTH_LONG).show();
        }
    }

    private void startBubble() {
        startService(new Intent(this, FloatingBubbleService.class));
        android.widget.Toast.makeText(this, "Floating AI icon enabled", android.widget.Toast.LENGTH_SHORT).show();
    }
}
