package com.example.quotexaipro;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class FloatingBubbleService extends Service {
    private WindowManager wm;
    private View bubble;
    private View panel;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        int overlayType = android.os.Build.VERSION.SDK_INT >= 26
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;

        TextView icon = new TextView(this);
        icon.setText("AI");
        icon.setTextColor(0xFFFFFFFF);
        icon.setTextSize(16);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(makeCircleBackground());
        bubble = icon;
        bubbleParams = new WindowManager.LayoutParams(58, 58, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.END;
        bubbleParams.x = 18; bubbleParams.y = 220;
        wm.addView(bubble, bubbleParams);

        bubble.setOnClickListener(v -> togglePanel());
        bubble.setOnTouchListener(new View.OnTouchListener() {
            private int sx, sy; private float tx, ty; private boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    sx = bubbleParams.x; sy = bubbleParams.y; tx = e.getRawX(); ty = e.getRawY(); moved = false; return false;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int dx = (int)(tx - e.getRawX()), dy = (int)(ty - e.getRawY());
                    if (Math.abs(dx) + Math.abs(dy) > 8) moved = true;
                    bubbleParams.x = Math.max(0, sx + dx); bubbleParams.y = Math.max(0, sy + dy);
                    wm.updateViewLayout(bubble, bubbleParams); return moved;
                }
                return false;
            }
        });
    }

    private android.graphics.drawable.GradientDrawable makeCircleBackground() {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        d.setColor(0xFF2563EB);
        d.setStroke(3, 0xFF93C5FD);
        return d;
    }

    private void togglePanel() {
        if (panel != null) {
            try { wm.removeView(panel); } catch (Exception ignored) {}
            panel = null; return;
        }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(24, 20, 24, 20);
        box.setBackgroundColor(0xF01E293B);
        TextView head = new TextView(this);
        head.setText("QUOTEX AI • Demo panel");
        head.setTextColor(0xFFFFFFFF); head.setTextSize(17);
        box.addView(head);
        TextView signal = new TextView(this);
        signal.setText("\nSignal: WAIT\nReason: Live candle feed / trained model not connected.\nConfidence: not available\n\nএটি demo; ট্রেডিং সিদ্ধান্তের জন্য ব্যবহার করবেন না।");
        signal.setTextColor(0xFFE2E8F0); signal.setTextSize(14);
        box.addView(signal);
        int overlayType = android.os.Build.VERSION.SDK_INT >= 26
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        panelParams = new WindowManager.LayoutParams(
            (int)(getResources().getDisplayMetrics().widthPixels * 0.78),
            WindowManager.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        panelParams.y = 300;
        panel = box; wm.addView(panel, panelParams);
        panel.setOnClickListener(v -> { try { wm.removeView(panel); } catch (Exception ignored) {} panel = null; });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }
    @Override public void onDestroy() {
        if (wm != null) {
            if (bubble != null) try { wm.removeView(bubble); } catch (Exception ignored) {}
            if (panel != null) try { wm.removeView(panel); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
