# QUOTEX AI PRO — Android starter (Option C)

এই প্রজেক্টটি Android Studio-তে build করার জন্য একটি starter source project। এতে আছে:
- Android-এর overlay permission নিয়ে floating AI bubble দেখানোর Service
- বাটনে চাপলে ছোট signal panel
- MediaProjection screen-capture permission নেওয়ার ভিত্তি (ব্যবহারকারীকে Android-এর system prompt-এ সম্মতি দিতে হবে)
- UP / DOWN / WAIT-এর demo indicator; এটি trained/validated ML model নয়

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি এখনই প্রস্তুত, পরীক্ষিত ট্রেডিং AI নয় এবং কোনো APK build/sign করা হয়নি। Quotex-এর স্ক্রিন থেকে নির্ভরযোগ্য candle extraction, broker-specific OTC data feed, backend, model training, walk-forward backtest ও live validation আলাদা করে সম্পন্ন করতে হবে। স্ক্রিনশট/ডেটা অনুমতি ছাড়া গোপনে নেওয়া হয় না। কোনো নির্ভুলতার নিশ্চয়তা নেই।

## Build করার জন্য
1. Android Studio-তে project খুলুন।
2. Gradle sync করুন।
3. Android 8.0+ ফোনে চালান।
4. অ্যাপের ভেতর “Enable floating icon” চাপুন এবং overlay permission দিন।
5. Screen capture integration-এ Android-এর system consent বাধ্যতামূলক।

## Market data / AI পরবর্তী ধাপ
- Backend-এ licensed market-data API যুক্ত করতে হবে; API secret APK-তে hard-code করবেন না।
- Quotex OTC candle-এর সঙ্গে external feed একই হবে ধরে নেওয়া যাবে না।
- একটি সত্যিকারের model দিতে হলে historical candle dataset, defined prediction horizon, out-of-sample/walk-forward test, fees/payout assumptions এবং measured metrics প্রয়োজন।

## মোবাইল থেকে APK build (GitHub Actions)
1. GitHub-এ সাইন ইন করে নতুন repository তৈরি করুন।
2. ZIP-টি ফোনে extract করুন; ভেতরের ফাইলগুলো repository-তে upload করুন (ZIP-কে শুধু এক ফাইল হিসেবে upload করবেন না)।
3. repository-র Actions ট্যাবে যান, “Build Android APK” workflow বেছে “Run workflow” চাপুন।
4. build সফল হলে workflow run-এর নিচে Artifacts থেকে `quotex-ai-pro-debug-apk` ডাউনলোড করুন।
5. ZIP artifact খুলে `app-debug.apk` ইনস্টল করুন। Android অজানা উৎস থেকে ইনস্টল অনুমতি চাইতে পারে।

এই workflow কেবল debug APK build করে; এটি live AI/market data যোগ করে না এবং Play Store-এর জন্য signed release নয়।
